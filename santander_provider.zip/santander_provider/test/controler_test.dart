import 'package:flutter_test/flutter_test.dart';
import 'package:santander_provider/src/models/product_model.dart';
import 'package:santander_provider/src/pages/home/home_controller.dart';
import 'package:santander_provider/src/services/home_service.dart';

void main() {
  test('Teste do Controller', () {
    HomeController homeController = HomeController(MockHomeService());

    expect(homeController.products, []);

    homeController.getAll();

    expect(homeController.products.length, 1);
  });
}

class MockHomeService implements IHomeService {
  @override
  Future<List<ProductModel>> getAll() async {
    return [ProductModel(id: 1, description: '', name: '')];
  }
}
