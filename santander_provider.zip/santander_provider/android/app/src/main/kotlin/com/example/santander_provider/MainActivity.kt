package com.example.santander_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
