import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:santander_provider/src/pages/home/home_controller.dart';

import 'src/app.dart';
import 'src/services/home_service.dart';

void main() {
  runApp(MultiProvider(providers: [
    //Provider.value = Singlethon
    //Provider(create: ) = LazySinglethon // Scoped
    //(context) => HomeService() = Factory

    // Provider(
    //   create: (context) => HomeService(),
    // ),

    Provider<HomeNatalService>.value(value: HomeNatalService()),
    Provider<HomeService>.value(value: HomeService()),
    // Provider(
    //   create: (context) => HomeNatalService()),
    // )
    ChangeNotifierProvider<HomeController>(
      create: (context) {
        if (DateTime.now().day != 25) {
          return HomeController(context.read<HomeNatalService>());
        }
        return HomeController(context.read<HomeService>());
      },
    ),
  ], child: const App()));
}
