import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'home_controller.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Page'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          var homeController = Provider.of<HomeController>(context, listen: false);
          homeController.getAll();
        },
        child: const Icon(Icons.add),
      ),
      body: AnimatedBuilder(
        animation: context.read<HomeController>(),
        builder: (context, child) {
          if (context.read<HomeController>().products.isEmpty) {
            return const Center(
              child: Text('No Data Found'),
            );
          }

          return ListView.builder(
            itemCount: context.read<HomeController>().products.length,
            itemBuilder: (context, index) {
              var currentProduct = context.read<HomeController>().products[index];
              return ListTile(
                title: Text(currentProduct.name),
                subtitle: Text(currentProduct.description),
                leading: const CircleAvatar(
                  backgroundColor: Colors.yellow,
                  child: Icon(Icons.add),
                ),
                trailing: const Icon(Icons.arrow_forward),
              );
            },
          );
        },
      ),
    );
  }
}
