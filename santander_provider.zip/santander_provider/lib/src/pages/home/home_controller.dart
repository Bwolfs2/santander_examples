import 'package:flutter/material.dart';
import 'package:santander_provider/src/models/product_model.dart';
import 'package:santander_provider/src/services/home_service.dart';

class HomeController extends ChangeNotifier {
  final IHomeService service;

  HomeController(this.service);

  List<ProductModel> products = [];

  Future<void> getAll() async {
    products = await service.getAll();
    notifyListeners();
    //future.then((data) {
    //  print('Antes');
    //  products = data;
    //  notifyListeners();
    //});

    print('Depois');

    //future.onError((error, stackTrace) {
    //  return Future.value([]);
    //});
  }
}
