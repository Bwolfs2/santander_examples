import 'package:santander_provider/src/models/product_model.dart';

//apiX
class HomeService implements IHomeService {
  @override
  Future<List<ProductModel>> getAll() async {
    await Future.delayed(Duration(seconds: 2));

    return List.generate(
      50,
      (index) => ProductModel(
        id: index,
        name: 'Produto $index',
        description: 'Descricao $index',
      ),
    );
  }
}

//apiNatal
class HomeNatalService implements IHomeService {
  @override
  Future<List<ProductModel>> getAll() async {
    await Future.delayed(Duration(seconds: 2));

    return List.generate(
      50,
      (index) => ProductModel(
        id: index,
        name: 'Produto Natalino $index',
        description: 'Descricao Natalino $index',
      ),
    );
  }
}

abstract class IHomeService {
  Future<List<ProductModel>> getAll();
}
