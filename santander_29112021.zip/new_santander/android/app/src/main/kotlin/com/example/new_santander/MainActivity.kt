package com.example.new_santander

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
