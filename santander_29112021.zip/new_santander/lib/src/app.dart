import 'package:flutter/material.dart';

import 'pages/todo_list/todo_list_page.dart';

class App extends StatefulWidget {
  final bool isProd;
  const App(
    this.isProd, {
    Key? key,
  }) : super(key: key);

  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: widget.isProd ? 'Flutter Prod' : "Flutter Dev",
      darkTheme: widget.isProd ? ThemeData.dark() : ThemeData(),
      home: const TodoListPage(),
    );
  }
}
