import 'package:new_santander/src/models/todo_model.dart';

class TodoMapper {
  static Map<String, dynamic> toMap(TodoModel todo) {
    return {
      'userId': todo.userId,
      'id': todo.id,
      'title': todo.title,
      'completed': todo.completed,
    };
  }

  static TodoModel fromMap(Map<String, dynamic> map) {
    return TodoModel(
      userId: map['userId'],
      id: map['id'],
      title: map['title'],
      completed: map['completed'],
    );
  }

  static List<TodoModel> fromList(List list) {
    return list
        .map((e) => TodoModel(
              userId: e['id'],
              id: e['id'],
              title: e['title'],
              completed: e['completed'],
            ))
        .toList();
  }
}
