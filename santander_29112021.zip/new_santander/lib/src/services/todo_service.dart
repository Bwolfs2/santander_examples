import 'package:new_santander/src/models/todo_model.dart';
import 'package:dio/dio.dart';
import 'package:new_santander/src/services/mapper/todo_mapper.dart';

abstract class ITodoService {
  Future<List<TodoModel>> getTodos();
}

class TodoService implements ITodoService {
  final Dio dio;

  TodoService(this.dio);

  @override
  Future<List<TodoModel>> getTodos() async {
    var result = await dio.get('/todos');
    return TodoMapper.fromList(result.data);
  }
}

class TodoServiceDEV implements ITodoService {
  Dio dio = Dio();

  @override
  Future<List<TodoModel>> getTodos() async {
    var result = await dio.get('https://jsonplaceholder.typicode.com/todos');

    return (result.data as List)
        .map((e) => TodoModel(
              userId: e['id'],
              id: e['id'],
              title: 'Development - ${e['title']}',
              completed: e['completed'],
            ))
        .toList();
  }
}
