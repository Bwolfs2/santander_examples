import 'package:flutter/material.dart';
import 'package:new_santander/src/pages/widget/items_list/items_list_controller.dart';
import 'package:provider/provider.dart';

class ItemsListWidget extends StatelessWidget {
  const ItemsListWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ItemListController>(
      builder: (context, value, child) => SizedBox(
        height: 150,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: value.value,
          itemBuilder: (context, index) => InkWell(
            onTap: () {
              value.addNewItem();
            },
            child: Container(
              margin: const EdgeInsets.all(10),
              height: 100,
              width: 100,
              decoration: BoxDecoration(border: Border.all(width: 2)),
              child: const Icon(Icons.ad_units),
            ),
          ),
        ),
      ),
    );
  }
}
