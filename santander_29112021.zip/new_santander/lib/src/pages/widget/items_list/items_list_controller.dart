import 'package:flutter/cupertino.dart';

class ItemListController extends ValueNotifier<int> {
  ItemListController() : super(1);

  void addNewItem() {
    value = value + 1;
  }
}
