import 'package:flutter/material.dart';

class CustomErrorWidget extends StatelessWidget {
  final String errorMesssage;
  const CustomErrorWidget(this.errorMesssage, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 200,
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            width: 4,
            color: Colors.red,
          ),
        ),
        child: Center(
            child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (1 == 2)
              const Icon(
                Icons.error,
                color: Colors.red,
                size: 50,
              ),
            if (1 == 1)
              const Icon(
                Icons.error,
                color: Colors.red,
                size: 50,
              ),
            if (1 == 8)
              const Icon(
                Icons.error,
                color: Colors.red,
                size: 50,
              ),
            Text(errorMesssage),
          ],
        )),
      ),
    );
  }
}
