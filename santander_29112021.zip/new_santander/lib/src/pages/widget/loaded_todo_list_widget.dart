import 'package:flutter/material.dart';
import 'package:new_santander/src/models/todo_model.dart';

class LoadedTodoListWidget extends StatelessWidget {
  final List<TodoModel> todos;
  const LoadedTodoListWidget({Key? key, required this.todos}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: todos.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(todos[index].title),
        );
      },
    );
  }
}
