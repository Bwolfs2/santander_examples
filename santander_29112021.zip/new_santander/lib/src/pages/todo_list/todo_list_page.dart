import 'package:flutter/material.dart';
import 'package:new_santander/src/models/todo_model.dart';
import 'package:new_santander/src/pages/todo_list/todo_list_controller.dart';
import 'package:new_santander/src/pages/widget/custom_error_widget.dart';
import 'package:new_santander/src/pages/widget/items_list/items_list_widget.dart';
import 'package:new_santander/src/pages/widget/loaded_todo_list_widget.dart';
import 'package:new_santander/src/services/todo_service.dart';
import 'package:provider/provider.dart';

class TodoListPage extends StatefulWidget {
  const TodoListPage({Key? key}) : super(key: key);

  @override
  _TodoListPageState createState() => _TodoListPageState();
}

class _TodoListPageState extends State<TodoListPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meus Todos'),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton(
            backgroundColor: Colors.red,
            onPressed: () async {
              var controller = context.read<TodoListController>();
              controller.error();
            },
            child: const Icon(Icons.error),
          ),
          SizedBox(height: 20),
          FloatingActionButton(
            onPressed: () async {
              var controller = context.read<TodoListController>();
              await controller.getTodos();
            },
            child: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          const ItemsListWidget(),
          Expanded(
            child: Consumer<TodoListController>(
              builder: (context, controller, child) {
                var state = controller.value;

                if (state is InitTodoListState) {
                  return Container();
                }

                if (state is ErrorTodoListState) {
                  return CustomErrorWidget(state.errroMessage);
                }

                if (state is LoadingTodoListState) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (state is LoadedTodoListState) {
                  if (state.todos.isEmpty) {
                    return const Center(child: Text('A lista Esta Vazia'));
                  }

                  return LoadedTodoListWidget(todos: state.todos);
                }

                return Center(
                  child: Text('Not Implemented'),
                );
              },
            ),
          ),
          const ItemsListWidget(),
        ],
      ),
    );
  }
}
