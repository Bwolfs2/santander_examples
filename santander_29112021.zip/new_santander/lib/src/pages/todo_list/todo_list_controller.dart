import 'package:flutter/cupertino.dart';
import 'package:new_santander/src/services/todo_service.dart';

import '../../models/todo_model.dart';

class TodoListController extends ValueNotifier<TodoListState> {
  final ITodoService _todoService;
  TodoListController(this._todoService) : super(InitTodoListState()) {
    getTodos();
  }

  Future<void> getTodos() async {
    value = LoadingTodoListState();
    var listTodo = await _todoService.getTodos();
    value = LoadedTodoListState(listTodo);
  }

  void error() {
    value = ErrorTodoListState();
  }
}

abstract class TodoListState {}

class InitTodoListState extends TodoListState {}

class LoadingTodoListState extends TodoListState {}

class LoadedTodoListState extends TodoListState {
  final List<TodoModel> todos;
  LoadedTodoListState(this.todos);
}

class ErrorTodoListState extends TodoListState {
  String errroMessage = 'Mensagem de erro';
}
