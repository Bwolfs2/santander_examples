import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:new_santander/src/pages/todo_list/todo_list_controller.dart';
import 'package:new_santander/src/pages/widget/items_list/items_list_controller.dart';
import 'package:new_santander/src/services/todo_service.dart';
import 'package:provider/provider.dart';
import 'src/app.dart';

void main() {
  runApp(MultiProvider(providers: [
    Provider.value(value: Dio(BaseOptions(baseUrl: 'https://jsonplaceholder.typicode.com'))),
    Provider<TodoService>(create: (context) => TodoService(context.read<Dio>())),
    ChangeNotifierProvider(create: (context) => ItemListController()),
    ChangeNotifierProvider<TodoListController>(
      create: (context) => TodoListController(context.read<TodoService>()),
    ),
  ], child: const App(true)));
}
