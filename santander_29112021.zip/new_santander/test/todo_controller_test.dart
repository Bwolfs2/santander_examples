import 'package:flutter_test/flutter_test.dart';
import 'package:new_santander/src/models/todo_model.dart';
import 'package:new_santander/src/pages/todo_list/todo_list_controller.dart';
import 'package:new_santander/src/services/todo_service.dart';

class TodoServiceMock implements ITodoService {
  @override
  Future<List<TodoModel>> getTodos() async {
    return [TodoModel(id: 1, userId: 2, completed: true, title: 'Mock Title')];
  }
}

void main() {
  test('Teste Controller', () async {
    //Arrange
    TodoListController controller = TodoListController(TodoServiceMock());
    //Act
    await controller.getTodos();
    //Assert
    //  expect(controller.todos.length, 1);
    //  expect(controller.todos[0].id, 1);
  });
}
